<?php
// Include db.php for database functions
include 'db.php';

// Check if form is submitted
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Retrieve the user data based on email (replace this with your database function)
    $user = readOne('users', "email = '$email'");
    echo("loading...");  // For debugging (you can remove this in production)

    // Check if the user exists
    if ($user) {
        // Check if the provided password matches the stored password
        if ($password === $user['password']) {  // Assuming the password is stored in plain text (not recommended)
            // If passwords match, show a success message and redirect to the home page

            // Store user ID in the session
            $_SESSION['userId'] = $user['id'];  // Store user ID in session variable

            echo "
                <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
                <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
                <script>
                    Swal.fire({
                        title: 'Success!',
                        text: 'Login successful!',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(function() {
                        // Store the email in localStorage
                        localStorage.setItem('email', '$email');
                        
                        // Redirect to the home page (index.php) after the SweetAlert is closed
                        window.location.href = 'index.php';
                    });
                </script>
            ";
        } else {
            // Incorrect password
            echo "
                <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
                <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
                <script>
                    Swal.fire({
                        title: 'Error!',
                        text: 'Incorrect password!',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    }).then(function() {
                        // Redirect back to the login page after the SweetAlert is closed
                        window.location.href = 'index.php';
                    });
                </script>
            ";
        }
    } else {
        // User not found
        echo "
            <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
            <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
            <script>
                Swal.fire({
                    title: 'Error!',
                    text: 'User not found!',
                    icon: 'error',
                    confirmButtonText: 'OK'
                }).then(function() {
                    // Redirect back to the login page after the SweetAlert is closed
                    window.location.href = 'index.php';
                });
            </script>
        ";
    }
}
?>