<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="shortcut icon" href="assets/imges/Logo-mini.svg" /> -->
    <!-- Font Popinse -->
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
        rel="stylesheet">
    <!-- Font Popinse -->

    <!-- Font Awesome  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"
        integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Font Awesome  -->

    <!-- Link Bootstrap  -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
    <!-- Link Bootstrap  -->

    <!-- Link css -->
    <link rel="stylesheet" href="style.css">

    <style>
    /* Button Go To Top End */

    /* Chat icon styling */
    .chat-icon {
        position: fixed;
        bottom: 20px;
        /* Distance from the bottom of the screen */
        right: 20px;
        /* Distance from the right of the screen */
        background-color: #22a17f;
        /* WhatsApp-like green */
        color: white;
        border-radius: 50%;
        padding: 15px;
        font-size: 20px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        cursor: pointer;
        z-index: 9999;
        /* Ensures the icon is always on top */
        transition: all 0.3s ease;
    }

    /* Hover effect */
    .chat-icon:hover {
        background-color: #128C7E;
        /* Darker green on hover */
    }
    </style>
    <!-- Link css -->

    <!-- Link Bootstrap Js  -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"
        integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous">
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous">
    </script>
    <!-- Link Bootstrap Js  -->


    <!-- <title>Doctor</title> -->
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- jQuery (for easier DOM manipulation) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>

<body>
    <!-- Header Start  -->
    <header>
        <!-- nav-bar Start -->
        <section class="nav-bar">
            <nav class="navbar navbar-expand-lg navbar-light fixed-top">
                <div class="container">
                    <a class="navbar-brand" href="#">
                        <!-- <img src="assets/imges/Logo.svg" alt="logo" width="150px"> -->
                        <i class="fa-solid fa-venus" style="font-size: 20px; color: #22a17f;"></i>
                        <span style="font-weight: 600;">Women <span style="color: #22a17f;">Security</span></span>
                    </a>
                    <button class="navbar-toggler" type="button" data-toggle="collapse"
                        data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto mr-5">
                            <li class="nav-item mx-2 active">
                                <a class="nav-link" href="#">Home</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="#about">About Us</a>
                            </li>
                            <!-- <li class="nav-item mx-2">
                                <a class="nav-link" href="#services">Services</a>
                            </li> -->
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="#team">Team</a>
                            </li>
                            <!-- <li class="nav-item mx-2">
                                <a class="nav-link" href="#facility">Facility</a>
                            </li> -->
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="laws.php">Women laws</a>
                            </li>
                            <li class="nav-item mx-2">
                                <a class="nav-link" href="#contact">Contact</a>
                            </li>
                            <!-- Dropdown for Documents -->
                            <li class="nav-item dropdown mx-2">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Documents
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <?php
                            include 'db.php';

                            // Assuming the 'read' function returns an array of rows
                            $data = read('youtube_links');

                            // Loop through the data
                            foreach ($data as $row) {
                                // Output the title in the dropdown with the link
                                echo '<a class="dropdown-item" href="' . $row['link'] . '" target="_blank">' . $row['title'] . '</a>';
                            }
                            ?>

                                    <!-- <a class="dropdown-item" href="#">New Criminal Laws</a>
                                    <a class="dropdown-item" href="#">Judicial Commission/Inquiry Commission Reports</a>
                                    <a class="dropdown-item" href="#">Archives</a>
                                    <a class="dropdown-item" href="#">Mutual Legal Assistance(MLA) in Criminal
                                        Matters</a>
                                    <a class="dropdown-item" href="#">Policies & Guidelines</a>
                                    <a class="dropdown-item" href="#">Subhas Chandra Bose Aapda Prabandhan</a> -->
                                </div>
                            </li>
                        </ul>
                        <div class="my-lg-0" id="btn__account">
                            <!-- <button class="btn btn-success px-5 py-2 my-sm-0" type="submit" data-bs-toggle="modal" data-bs-target="#authModal" >Register Now</button> -->
                        </div>
                    </div>
                </div>
            </nav>
        </section>

        <!-- nav-bar End-->
        <!-- Main Header  Start-->
        <section class="main-header">
            <div class="container">
                <!-- <div class="pulser"></div>
                <div class="animation-effect">
                    <div class="effect-1">
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                        <div></div>
                    </div>
                    <div class="effect-2"></div>
                </div> -->
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                        <div class="main-header_text">
                            <div class="section-header">
                                Women
                                <br>
                                <span style="color: #22a17f;">
                                    Security & Reliance
                                </span>
                            </div>
                            <div class="section-body">
                                <p>
                                    Women’s security and its reliance are vital to ensuring that women can live and
                                    thrive in a society free from violence and fear. It encompasses physical protection,
                                    legal rights, and the support systems needed to empower women to pursue their goals
                                    safely. Achieving this requires strong laws, social change, and a collective effort
                                    to prioritize women’s well-being.
                                </p>
                            </div>
                            <div class="section-action">
                                <a href="./hero1.html" target="_blanck" class="btn btn-success px-5 py-2">Read
                                    Article</a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                        <div class="main-header_image">
                            <div class="circle-effect"></div>
                            <!-- <div class="box-lift">
                                <div class="media">
                                    <div class="icon">
                                        <i class="fa-solid fa-users"></i>
                                    </div>
                                    <div class="media-body">
                                        <h5 class="mt-0">1520+</h5>
                                        <p>Activate Clients</p>
                                    </div>
                                </div>
                            </div> -->

                            <div class="image">
                                <img class="img-fluid" style="width: 400px;" src="public/women.svg" alt="" srcset="">
                            </div>

                            <!-- <div class="box-rigth">
                                <p>
                                    <span class="icon"><i class="fa-solid fa-check"></i></span>
                                    Get 20% off on every 1st month
                                    <br>
                                    <span class="icon"><i class="fa-solid fa-check"></i></span>
                                    Expert Doctors
                                </p>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- Main Header  Start-->
    </header>
    <!-- Header End  -->

    <!-- About Us Start -->
    <section class="about" id="about">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                    <div class="about_text">
                        <div class="section-header">
                            <!-- <img src="assets/imges/Logo-mini.svg" width="60px"> -->
                            Women's Safty <span>Matters!</span>
                        </div>
                        <div class="section-body">
                            <p>
                                Women's safety matters because it is essential for ensuring their freedom, dignity, and
                                equal participation in society. When women feel safe, they can pursue their dreams,
                                contribute to communities, and lead fulfilling lives. Prioritizing women’s safety is
                                crucial for building a just and equitable society for all.
                            </p>
                        </div>
                        <div class="section-action">
                            <a href="./hero2.html" target="_blanck" class="btn btn-success px-5 py-2">Read
                                Article</a>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
                    <div class="about_image">
                        <img class="img-fluid" src="public/group.jfif">
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- About Us End -->

    <!-- Services Start -->
    <section class="services" id="services">
        <div class="container">
            <div class="header-section mb-5">
                <h1><i class="fa-solid fa-venus" style="color: #22a17f;font-size: 40px"></i> Our Courses</h1>
            </div>
            <div class="body-section">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist"
                            aria-orientation="vertical">
                            <!-- <button class="nav-link active text-left" id="v-pills-teeth-cleaning-tab" data-toggle="pill"
                                data-target="#v-pills-teeth-cleaning" type="button" role="tab"
                                aria-controls="v-pills-teeth-cleaning" aria-selected="true">1. Teeth Cleaning</button>
                            <button class="nav-link text-left" id="v-pills-teeth-whitening-tab" data-toggle="pill"
                                data-target="#v-pills-teeth-whitening" type="button" role="tab"
                                aria-controls="v-pills-teeth-whitening" aria-selected="false">2. Teeth
                                Whitening</button>
                            <button class="nav-link text-left" id="v-pills-radiographs-tab" data-toggle="pill"
                                data-target="#v-pills-radiographs" type="button" role="tab"
                                aria-controls="v-pills-radiographs" aria-selected="false">3. Radiographs</button>
                            <button class="nav-link text-left" id="v-pills-sports-guards-tab" data-toggle="pill"
                                data-target="#v-pills-sports-guards" type="button" role="tab"
                                aria-controls="v-pills-sports-guards" aria-selected="false">4. Sports Guards</button>
                            <button class="nav-link text-left" id="v-pills-pediatric-work-tab" data-toggle="pill"
                                data-target="#v-pills-pediatric-work" type="button" role="tab"
                                aria-controls="v-pills-pediatric-work" aria-selected="false">5. Pediatric Work</button> -->
                            <?php

// Assuming the 'read' function returns an array of rows
$data = read('courses');

// Counter to track the first iteration
$first = true;

// Loop through the data
foreach ($data as $row) {
    // Check if it's the first iteration
    $activeClass = $first ? 'active' : '';

    // Output the title in the dropdown with the link
    echo
    ' <button class="nav-link text-left ' . $activeClass . '" id="v-'.$row['id'].'-tab" data-toggle="pill"
        data-target="#v-'.$row['id'].'" type="button" role="tab"
        aria-controls="v-'.$row['id'].'" aria-selected="false">'.$row['title'].'</button>
    ';
    
    // Set the first iteration to false after the first loop
    $first = false;
}
?>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-8 col-lg-8">
                        <div class="tab-content" id="v-pills-tabContent">

                            <!-- 
                            <div class="tab-pane fade show active" id="v-pills-teeth-cleaning" role="tabpanel"
                                aria-labelledby="v-pills-teeth-cleaning-tab">
                                <h3 class="title">1. Teeth Cleaning</h3>
                                <p class="content">
                                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry
                                    richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor
                                    brunch.
                                    <br>
                                    Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
                                    put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil
                                    anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea
                                    proident.
                                </p>
                            </div>
                            <div class="tab-pane fade" id="v-pills-teeth-whitening" role="tabpanel"
                                aria-labelledby="v-pills-teeth-whitening-tab">
                                <h3 class="title">2. Teeth Whitening</h3>
                                <p>
                                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry
                                    richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor
                                    brunch.
                                    <br>
                                    Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
                                    put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil
                                    anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea
                                    proident.
                                </p>
                            </div>
                            <div class="tab-pane fade" id="v-pills-radiographs" role="tabpanel"
                                aria-labelledby="v-pills-radiographs-tab">
                                <h3 class="title">3. Radiographs</h3>
                                <p class="content">
                                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry
                                    richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor
                                    brunch.
                                    <br>
                                    Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
                                    put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil
                                    anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea
                                    proident.
                                </p>
                            </div>
                            <div class="tab-pane fade" id="v-pills-sports-guards" role="tabpanel"
                                aria-labelledby="v-pills-sports-guards-tab">
                                <h3 class="title">4. Sports Guards</h3>
                                <p class="content">
                                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry
                                    richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor
                                    brunch.
                                    <br>
                                    Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
                                    put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil
                                    anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea
                                    proident.
                                </p>
                            </div>
                            <div class="tab-pane fade" id="v-pills-pediatric-work" role="tabpanel"
                                aria-labelledby="v-pills-pediatric-work-tab">
                                <h3 class="title">5. Pediatric Work</h3>
                                <p class="content">
                                    Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry
                                    richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor
                                    brunch.
                                    <br>
                                    Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua
                                    put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil
                                    anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea
                                    proident.
                                </p>
                            </div> -->
                            <?php

// Assuming the 'read' function returns an array of rows
$data = read('courses');

// Counter to track the first iteration
$first = true;

// Loop through the data
foreach ($data as $row) {
    // Check if it's the first iteration
    $activeClass = $first ? 'active show' : '';

    // Output the tab pane with the content
    echo
    '<div class="tab-pane fade ' . $activeClass . '" id="v-'.$row['id'].'" role="tabpanel"
        aria-labelledby="v-'.$row['id'].'-tab">
        <h3 class="title">'.$row['title'].'</h3>
        <p class="content">
            '.$row['description'].'
        </p>
         <div class="button-container text-right">
            <a href="course-form.php?id='.$row['id'].'" class="btn btn-success px-5 py-2" target="_blank">Read More</a>
        </div>
    </div>
    ';
    
    // Set the first iteration to false after the first loop
    $first = false;
}
?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Services End -->

    <!-- Team Start -->
    <section class="team" id="team">
        <div class="container">
            <div class="header-section mb-5">
                <h1> <i class="fa-solid fa-user-group" style="font-size: 40px; color: #22a17f;"></i> Meet Our Team</h1>
            </div>
            <div class="body-section">
                <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="card text-center mb-4">
                            <div class="image">
                                <img src="public/Ashit1.jpg" class="card-img-top">
                            </div>
                            <div class="card-body">
                                <h4 class="card-title">Ashit Hiwrale</h4>
                                <!-- <p class="card-text">Neurosurgeons</p>
                                <a href="#" class="icon"><i class="fa-brands fa-facebook"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-twitter"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-instagram"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-linkedin"></i></a> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="card text-center mb-4">
                            <div class="image">
                                <img src="public/Bhagwati Borade1.jpg" class="card-img-top">
                            </div>
                            <div class="card-body">
                                <h4 class="card-title">Bhagawati Borade</h4>
                                <!-- <p class="card-text">Infectious diseases.</p>
                                <a href="#" class="icon"><i class="fa-brands fa-facebook"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-twitter"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-instagram"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-linkedin"></i></a> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="card text-center mb-4">
                            <div class="image ">
                                <img src="public/Sanika Raut1.jpeg" class="card-img-top">
                            </div>
                            <div class="card-body">
                                <h4 class="card-title">Sanika Raut</h4>
                                <!-- <p class="card-text">Microbiology</p>
                                <a href="#" class="icon"><i class="fa-brands fa-facebook"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-twitter"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-instagram"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-linkedin"></i></a> -->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row d-flex justify-content-center">
                    <!-- <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="card text-center mb-4">
                            <div class="image">
                                <img src="assets/imges/team-1.png" class="card-img-top">
                            </div>
                            <div class="card-body">
                                <h4 class="card-title">Vanita Sarate</h4>
                                <p class="card-text">Neurosurgeons</p>
                                <a href="#" class="icon"><i class="fa-brands fa-facebook"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-twitter"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-instagram"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-linkedin"></i></a>
                            </div>
                        </div>
                    </div> -->
                    <div class="col-xs-12 col-sm-12 col-md-4 col-lg-4">
                        <div class="card text-center mb-4">
                            <div class="image">
                                <img src="public/Shraddha Wagh1.jpeg" class="card-img-top">
                            </div>
                            <div class="card-body">
                                <h4 class="card-title">Shraddha Wagh</h4>
                                <!-- <p class="card-text">Infectious diseases.</p>
                                <a href="#" class="icon"><i class="fa-brands fa-facebook"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-twitter"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-instagram"></i></a>
                                <a href="#" class="icon"><i class="fa-brands fa-linkedin"></i></a> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Team End -->


    <!-- Facility Start -->
    <section class="facility" id="facility">
        <div class="container">
            <div class="header-section ">
                <h1><i class="fa-solid fa-venus" style="color: #22a17f;font-size: 40px"></i> Services</h1>
            </div>
            <div class="body-section">
                <div class="row">
                    <?php

// Assuming the 'read' function returns an array of rows
$data = read('services');

// Loop through the data
foreach ($data as $row) {
    // Check if it's the first iteration

    // Output the tab pane with the content
    echo '
<div class="col-xs-12 col-sm-6 col-md-6 col-lg-4">
    <div class="card text-center">
        <div class="icon mb-3">
            <i class="fa-solid fa-user-graduate"></i>
        </div>
        <h3 class="title mb-5">'.$row['title'].'</h3>
        <p class="content mb-3">
            '.$row['short_description'].'
        </p>
        <b class="content mb-3">';
        
        // Check if the fees are 0, if so, display "Free" otherwise display the fee
        if ($row['fees'] == 0) {
            echo 'Free';
        } else {
            echo 'Only at Rs. '.$row['fees'].'/-';
        }

echo '
        </b>
        <div class="button-container text-center">
            <a href="service-form.php?id='.$row['id'].'&fees='.$row['fees'].'" class="btn btn-success px-5 py-2" target="_blank">Read More</a>
        </div>
    </div>
</div>
';
    
}
?>

                </div>
            </div>
        </div>
    </section>
    <!-- Facility End -->

    <!-- Partners Start -->
    <section class="partners" id="partners">
        <div class="container">
            <div class="row mx-auto my-auto justify-content-center">
                <div id="recipeCarousel" class="carousel slide" data-ride="carousel">
                    <div class="carousel-inner" role="listbox">
                        <div class="carousel-item active">
                            <div class="col-lg-2">
                                <div class="logo-card m-1">
                                    <div class="logo-img">
                                        <a href="#"><img src="public/swach-bharat.png" class="img-fluid"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item ">
                            <div class="col-lg-2">
                                <div class="logo-card m-1">
                                    <div class="logo-img">
                                        <a href="#"><img src="public/1test.png" class="img-fluid"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item ">
                            <div class="col-lg-2">
                                <div class="logo-card m-1">
                                    <div class="logo-img">
                                        <a href="#"><img src="public/AKAM_logo.jpg" class="img-fluid"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item ">
                            <div class="col-lg-2">
                                <div class="logo-card m-1">
                                    <div class="logo-img">
                                        <a href="#"><img src="public/G20New.jpg" class="img-fluid"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item ">
                            <div class="col-lg-2">
                                <div class="logo-card m-1">
                                    <div class="logo-img">
                                        <a href="#"><img src="public/Yoga_India_new.jpg" class="img-fluid"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item ">
                            <div class="col-lg-2">
                                <div class="logo-card m-1">
                                    <div class="logo-img">
                                        <a href="#"><img src="public/makeinindia.png" class="img-fluid"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item ">
                            <div class="col-lg-2">
                                <div class="logo-card m-1">
                                    <div class="logo-img">
                                        <a href="#"><img src="public/mygov.png" class="img-fluid"></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Partners End -->

    <!-- Contact Us Start -->
    <div class="contact" id="contact">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="header-section mb-5">
                        <h1>
                            <!-- <img src="assets/imges/Logo-mini.svg" width="60px"> -->
                            <i class="fa-solid fa-venus" style="color: #22a17f;font-size: 38px"></i>
                            Contact Us
                        </h1>
                    </div>
                    <div class="body-section">
                        <div class="info mb-3">
                            <div class="media">
                                <div class="icon">
                                    <i class="fa-solid fa-users"></i>
                                </div>
                                <div class="media-body">
                                    <h5 class="mt-0">Our Address</h5>
                                    <p>GP Ambad</p>
                                </div>
                            </div>
                        </div>
                        <div class="info mb-3">
                            <div class="media">
                                <div class="icon">
                                    <i class="fa-solid fa-users"></i>
                                </div>
                                <div class="media-body">
                                    <h5 class="mt-0">Phone</h5>
                                    <p>+91 9172939740</p>
                                </div>
                            </div>
                        </div>
                        <div class="info mb-3">
                            <div class="media">
                                <div class="icon">
                                    <i class="fa-solid fa-users"></i>
                                </div>
                                <div class="media-body">
                                    <h5 class="mt-0">Open Hours</h5>
                                    <p>Mn - St: 8:00am - 9:00pm Sn: Closed</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
                    <div class="map">
                        <iframe
                            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d103183.18011098167!2d75.3393!3d19.8758!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bd5bcf4cc8fa9fd%3A0x6b85b3a0b6703ef!2sAmbad%2C%20Maharashtra%2C%20India!5e0!3m2!1sen!2sin!4v1690312625807!5m2!1sen!2sin"
                            style="border:0;" allowfullscreen="" loading="lazy"
                            referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Contact Us End -->

    <!-- Footer Start -->
    <footer class="border-top pt-3">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-7 col-lg-5 mb-5">
                    <div class="logo">
                        <!-- <img src="assets/imges/Logo.svg" width="150px"> -->
                        <i class="fa-solid fa-venus" style="color: #22a17f;font-size: 28px"></i>
                        <span style="font-weight: 600; font-size: 30px;">Women <span
                                style="color: #22a17f;">Security</span></span>
                    </div>
                    <p class="text-muted text-center p-2"><b>"The best protection any woman can have is courage."</b>
                    </p>
                    <div class="text-center" style="margin-right: -200px;">
                        - Elizabeth Cady Stanton
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-5 col-lg-3 mb-5">
                    <h5>Quick Links</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2">
                            <a href="#" class="nav-link p-0 text-muted">Home</a>
                        </li>
                        <li class="nav-item mb-2">
                            <a href="#about" class="nav-link p-0 text-muted">About Us</a>
                        </li>
                        <!-- <li class="nav-item mb-2">
                            <a href="#services" class="nav-link p-0 text-muted">Services</a>
                        </li> -->
                        <li class="nav-item mb-2">
                            <a href="#team" class="nav-link p-0 text-muted">Team</a>
                        </li>
                        <li class="nav-item mb-2">
                            <a href="#partners" class="nav-link p-0 text-muted">Partners</a>
                        </li>
                        <li class="nav-item mb-2">
                            <a href="#contact" class="nav-link p-0 text-muted">Contact</a>
                        </li>
                    </ul>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-4 mb-5">
                    <h5>Contact Us</h5>
                    <div class="info mb-2">
                        <span>Location :</span> GP Ambad
                    </div>
                    <div class="info mb-2">
                        <span>Tel :</span> +91 9172939740
                    </div>
                    <div class="info mb-2">
                        <span>Email :</span> ashithiwrale@gmail.com
                    </div>
                    <div class="icons  d-flex align-items-start">
                        <div class="icon">
                            <a href="http://"><i class="fa-brands fa-facebook"></i></a>
                        </div>

                        <div class="icon">
                            <a href="http://"><i class="fa-brands fa-twitter"></i></a>
                        </div>

                        <div class="icon">
                            <a href="http://"><i class="fa-brands fa-linkedin"></i></a>
                        </div>
                    </div>
                </div>

            </div>
            <!-- <div class="footer-bottom text-center border-top pt-2 pb-2">
                Copyright &copy; 2023 Merabet Abdelkarim All Rights Reserved
            </div> -->
        </div>
        <a href="tel:+919172939740" class="chat-icon">
            <i class="fa-solid fa-phone"></i>
        </a>
    </footer>
    <!-- Modal -->
    <div class="modal fade" id="authModal" tabindex="-1" aria-labelledby="authModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="authModalLabel">Authentication</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <!-- Buttons to switch between Login and Sign Up -->
                    <div class="d-flex justify-content-center mb-3">
                        <button id="loginBtn" class="btn btn-success w-48 mx-2">Login</button>
                        <button id="signupBtn" class="btn btn-outline-success w-48 mx-2">Sign Up</button>
                    </div>

                    <!-- Login Form (Visible by default) -->
                    <div id="loginForm">
                        <form action="login.php" method="POST">
                            <div class="mb-3">
                                <label for="loginEmail" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="signupEmail" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="loginPassword" class="form-label">Password</label>
                                <input type="password" class="form-control" id="signupPassword" name="password"
                                    required>
                            </div>
                            <div class="d-flex justify-content-center mb-3">
                                <button type="submit" class="btn btn-success px-5 py-2 my-sm-0">Login</button>
                            </div>
                        </form>
                    </div>

                    <!-- Signup Form -->
                    <div id="signupForm" class="d-none">
                        <form action="signup.php" method="POST">
                            <div class="mb-3">
                                <label for="signupEmail" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="signupEmail" name="email" required>
                            </div>
                            <div class="mb-3">
                                <label for="signupPassword" class="form-label">Password</label>
                                <input type="password" class="form-control" id="signupPassword" name="password"
                                    required>
                            </div>
                            <div class="mb-3">
                                <label for="signupConfirmPassword" class="form-label">Confirm Password</label>
                                <input type="password" class="form-control" id="signupConfirmPassword"
                                    name="confirmPassword" required>
                            </div>
                            <div class="d-flex justify-content-center mb-3">
                                <button type="submit" class="btn btn-success px-5 py-2 my-sm-0">Sign Up</button>
                            </div>
                        </form>
                    </div>


                </div>
            </div>
        </div>
    </div>
    <!-- Footer End -->

    <!-- Button Go To Top Start -->
    <!-- <a href="#" class="to-top">
        <i class="fas fa-chevron-up"></i>
    </a> -->
    <!-- Button Go To Top End -->
    <script>
    // Logo partners time Start 
    $('#recipeCarousel').carousel({
        interval: 3000
    })
    // Logo partners time End

    // Logo partners  Start 
    $('.carousel .carousel-item').each(function() {
        var minPerSlide = 4;
        var next = $(this).next();
        if (!next.length) {
            next = $(this).siblings(':first');
        }
        next.children(':first-child').clone().appendTo($(this));

        for (var i = 0; i < minPerSlide; i++) {
            next = next.next();
            if (!next.length) {
                next = $(this).siblings(':first');
            }

            next.children(':first-child').clone().appendTo($(this));
        }
    });
    // Logo partners  End

    // Button Go To Top Start
    const toTop = document.querySelector(".to-top");
    window.addEventListener("scroll", () => {
        if (window.pageYOffset > 100) {
            toTop.classList.add("active");
        } else {
            toTop.classList.remove("active");
        }
    })
    // Button Go To Top End

    $(window).scroll(function() {
        if ($(document).scrollTop() > 50) {
            $('.navbar').addClass('affix');
            console.log("OK");
        } else {
            $('.navbar').removeClass('affix');
        }
    });
    </script>

    <!-- modal script -->
    <script>
    $(document).ready(function() {
        // Show login form by default
        $('#signupForm').addClass('d-none');

        // When the login button is clicked, show login form and hide signup form
        $('#loginBtn').on('click', function() {
            $('#loginForm').removeClass('d-none');
            $('#signupForm').addClass('d-none');
            $('#loginBtn').addClass('btn-primary').removeClass('btn-outline-primary');
            $('#signupBtn').addClass('btn-outline-primary').removeClass('btn-primary');
        });

        // When the signup button is clicked, show signup form and hide login form
        $('#signupBtn').on('click', function() {
            $('#signupForm').removeClass('d-none');
            $('#loginForm').addClass('d-none');
            $('#signupBtn').addClass('btn-primary').removeClass('btn-outline-primary');
            $('#loginBtn').addClass('btn-outline-primary').removeClass('btn-primary');
        });
    });
    </script>
    <!-- login condition -->
    <script>
    // Check if email exists in localStorage
    const userEmail = localStorage.getItem('email');
    const accountContainer = document.getElementById('btn__account');

    if (userEmail) {
        const profileContainer = document.createElement('div');
        profileContainer.classList.add('text-center');

        // Create the profile icon (FontAwesome)
        const profileIcon = document.createElement('i');
        profileIcon.classList.add('fas', 'fa-user-circle', 'fa-3x');
        profileIcon.style.cursor = 'pointer'; // Change cursor to pointer on hover
        profileIcon.setAttribute('data-bs-toggle', 'dropdown');
        profileIcon.setAttribute('aria-expanded', 'false');
        profileIcon.style.fontSize = '35px'

        // Create the email text below the icon
        const emailText = document.createElement('p');
        emailText.textContent = userEmail;
        emailText.style.cursor = 'pointer'; // Change cursor to pointer on hover
        emailText.setAttribute('data-bs-toggle', 'dropdown');
        emailText.setAttribute('aria-expanded', 'false');

        // Create the dropdown menu
        const dropdownDiv = document.createElement('div');
        dropdownDiv.classList.add('dropdown', 'mt-2');

        // Dropdown menu items (This can be added dynamically if required)
        const dropdownMenu = document.createElement('ul');
        dropdownMenu.classList.add('dropdown-menu');

        const dropdownItem1 = document.createElement('li');
        const link1 = document.createElement('a');
        link1.classList.add('dropdown-item');
        link1.href = 'chat/';
        link1.textContent = 'chat';
        dropdownItem1.appendChild(link1);

        const dropdownItem2 = document.createElement('li');
        const link2 = document.createElement('a');
        link2.classList.add('dropdown-item');
        link2.href = '#';
        link2.textContent = 'Logout';
        link2.addEventListener('click', handleLogout); // Call handleLogout when Logout is clicked
        dropdownItem2.appendChild(link2);

        dropdownMenu.appendChild(dropdownItem1);
        dropdownMenu.appendChild(dropdownItem2);

        // Append everything together
        dropdownDiv.appendChild(dropdownMenu);
        profileContainer.appendChild(profileIcon);
        profileContainer.appendChild(emailText);
        profileContainer.appendChild(dropdownDiv);

        accountContainer.appendChild(profileContainer);
    } else {
        // If no email is found, create and display the Register Now button
        const registerBtn = document.createElement('button');
        registerBtn.className = 'btn btn-success px-5 py-2 my-sm-0';
        registerBtn.textContent = 'Account';
        registerBtn.type = 'submit';
        registerBtn.setAttribute('data-bs-toggle', 'modal');
        registerBtn.setAttribute('data-bs-target', '#authModal');
        accountContainer.appendChild(registerBtn); // Append the button to the div
    }

    function handleLogout() {
        // Clear localStorage
        localStorage.removeItem('email');

        // Show SweetAlert message
        Swal.fire({
            title: 'Logout Successful',
            text: 'You have been logged out successfully.',
            icon: 'success',
            confirmButtonText: 'OK'
        }).then(function() {
            location.reload(); // This will reload the current page
        });
    }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>