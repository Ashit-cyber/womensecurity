<?php
// Database connection configuration
$servername = "localhost";
$username = "root";  // Default for XAMPP
$password = "";      // Default for XAMPP (set your password if you changed it)
$dbname = "womenSecurity"; // Replace with your database name

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the 'id' from the URL
$id = isset($_GET['id']) ? $_GET['id'] : 0;

// Fetch the blog data from the database based on the 'id'
$sql = "SELECT * FROM services WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);  // 'i' means the parameter is an integer
$stmt->execute();
$result = $stmt->get_result();

// Check if a result was found
if ($result->num_rows > 0) {
    // Fetch the data
    $row = $result->fetch_assoc();
    $title = $row['title'];
    $short_description = $row['short_description'];
    $description = $row['description'];
    $fees = $row['fees'];
} else {
    // Handle the case where no data is found
    $title = " Post Not Found";
    $short_description = "Sorry, the  post you are looking for does not exist.";
    $description = "Please try another  post.";
    $fees = "0";
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo htmlspecialchars($title); ?>
    </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KyZXEJf+Xf5Fq1fQhl+aDbXTw93U/hgVeGvqG7cz7/tf07VjfwB4yC0IQj0O0XQ0" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
        body {
            background-color: #f7f7f7;
            font-family: 'Arial', sans-serif;
        }

        .btn-success {
            background-color: #28be97;
            padding: 10px 20px;
            border-radius: 8px;
            text-decoration: none;
            color: white;
        }

        .btn-success:hover {
            background-color: #22a17f;
        }

        .blog-header {
            background-color: #28be97;
            color: white;
            padding: 50px;
        }

        .blog-header h1 {
            font-size: 3.5rem;
        }

        .blog-header p {
            font-size: 1.25rem;
        }

        .blog-content {
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .blog-content h3 {
            font-size: 2rem;
            color: #333;
            margin-bottom: 20px;
        }

        .blog-content p {
            font-size: 1.125rem;
            line-height: 1.6;
            color: #555;
        }

        .blog-footer {
            background-color: #28be97;
            color: white;
            padding: 20px 0;
            text-align: center;
        }

        .blog-footer a {
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        #enrollForm {
            display: none;
            /* Initially hide the form */
            margin-top: 20px;
        }
    </style>
</head>

<body>
    <div>
        <!-- Blog Header -->
        <div class="row blog-header text-center">
            <div class="col-12">
                <h1>
                    <?php echo htmlspecialchars($title); ?>
                </h1>
                <p class="lead">
                    <?php echo htmlspecialchars($short_description); ?>
                </p>
            </div>
        </div>

        <!-- Blog Content -->
        <div class="row justify-content-center">
            <div class="col-12 col-md-8">
                <!-- Blog Description -->
                <div class="blog-content">
                    <div style="display: flex;justify-content: space-between;">
                        <h3>
                            <?php echo htmlspecialchars($title); ?>
                        </h3>
                        <div class="">
                            <?php 
                            if ($fees == 0) {
                                echo "Free";
                            } else {
                                echo "Rs. " . htmlspecialchars($fees);
                            }
                            ?>
                        </div>

                    </div>
                    <p>
                        <?php echo htmlspecialchars($description); ?>
                    </p>
                    <div class="button-container" style="display: flex; justify-content: center;">
                        <!-- Enroll Now Button -->
                        <a href="javascript:void(0);" class="btn btn-success px-5 py-2" onclick="showForm()">Enroll
                            now</a>
                    </div>

                    <!-- Enroll Form (Initially Hidden) -->
                    <div id="enrollForm">
                        <div class="container mt-5 d-flex justify-content-center">
                            <div class="card" style="width: 100%; max-width: 600px;">
                                <div class="card-body">
                                    <h2 class="card-title text-center mb-4">Enroll Form</h2>
                                    <form method="POST" action="">
                                        <div class="mb-3 mt-3">
                                            <label for="name">Name:</label>
                                            <input type="text" class="form-control" id="name" placeholder="Enter Name"
                                                name="name" required>
                                        </div>
                                        <div class="mb-3 mt-3">
                                            <label for="phone">Phone no.:</label>
                                            <input type="tel" class="form-control" id="phone"
                                                placeholder="Enter phone number" name="phone" required>
                                        </div>
                                        <div class="mb-3 mt-3">
                                            <label for="email">Email:</label>
                                            <input type="email" class="form-control" id="email"
                                                placeholder="Enter email" name="email" required>
                                        </div>
                                        <div class="mb-3">
                                            <label for="address">Address:</label>
                                            <textarea class="form-control" name="address" id="address"
                                                required></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-success w-100">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- Blog Footer -->
    <div class="blog-footer">
        <p><a href="#">Back to Top</a></p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-pzjw8f+ua7Kw1TIq0Jv9pmb5a8b27V+h9P36jsbm5mMm7VcBdWrwF4IW3d2cQ4tw" crossorigin="anonymous">
        </script>

    <script>
        // JavaScript function to toggle form visibility
        function showForm() {
            // Hide the "Enroll now" button
            document.querySelector('.btn-success').style.display = 'none';

            // Show the form
            document.getElementById('enrollForm').style.display = 'block';

            // Check if email exists in localStorage
            const storedEmail = localStorage.getItem('email');

            if (storedEmail) {
                // If email exists in localStorage, bind it to the email input
                document.getElementById('email').value = storedEmail;
            } else {
                // If email doesn't exist, show SweetAlert and redirect to index.php
                Swal.fire({
                    title: 'Unauthorized',
                    text: 'You need to be logged in to enroll.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'index.php'; // Redirect to index.php
                });
            }
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>

</html>
<?php
// Database connection configuration
$servername = "localhost";
$username = "root";  // Default for XAMPP
$password = "";      // Default for XAMPP (set your password if you changed it)
$dbname = "womenSecurity"; // Replace with your database name

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture the form data
    $name = isset($_POST['name']) ? $_POST['name'] : '';
    $phone = isset($_POST['phone']) ? $_POST['phone'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $address = isset($_POST['address']) ? $_POST['address'] : '';

    // Get the service_id from the URL parameter
    $service_id = isset($_GET['id']) ? $_GET['id'] : 0;

    // Find the user ID based on the email
    $sql = "SELECT id FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);  // 's' means the parameter is a string
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch the user_id from the result
        $row = $result->fetch_assoc();
        $user_id = $row['id'];
    } else {
        // If no user is found, handle the error
        echo "<script>
            Swal.fire({
                title: 'Error!',
                text: 'User not found.',
                icon: 'error',
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.href = 'index.php';
            });
        </script>";
        exit;
    }

    // Check if the enrollment already exists for this user and service
    $checkSql = "SELECT * FROM enrollments WHERE user_id = ? AND service_id = ?";
    $checkStmt = $conn->prepare($checkSql);
    $checkStmt->bind_param("ii", $user_id, $service_id);  // 'ii' means the parameters are integers
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();

    if ($checkResult->num_rows > 0) {
        // If a record already exists, show SweetAlert and redirect to index.php
        echo "<script>
            Swal.fire({
                title: 'Already Exists!',
                text: 'You are already enrolled in this service.',
                icon: 'warning',
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.href = 'index.php';
            });
        </script>";
        exit;
    }

    // Insert the data into the enrollments table if not already enrolled
    $insertSql = "INSERT INTO enrollments (user_id, service_id, name, phone, email, address) 
                  VALUES (?, ?, ?, ?, ?, ?)";
    $insertStmt = $conn->prepare($insertSql);
    $insertStmt->bind_param("iissss", $user_id, $service_id, $name, $phone, $email, $address);
    $insertStmt->execute();

    if ($insertStmt->affected_rows > 0) {
        // Success: Show SweetAlert success and redirect to index.php
        echo "<script>
            Swal.fire({
                title: 'Payment Successful!',
                text: 'Enrollment saved successfully!',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.href = 'index.php';
            });
        </script>";
    } else {
        // Error: Show SweetAlert error and redirect to index.php
        echo "<script>
            Swal.fire({
                title: 'Error!',
                text: 'Failed to save enrollment.',
                icon: 'error',
                confirmButtonText: 'OK'
            }).then(() => {
                window.location.href = 'index.php';
            });
        </script>";
    }
}

// Close the database connection
$conn->close();
?>