<?php
// Include db.php for database functions
include 'db.php';

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get the form data
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirmPassword = trim($_POST['confirmPassword']);

    // Basic validation to ensure the passwords match
    if ($password !== $confirmPassword) {
        echo "
            <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
            <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
            <script>
                Swal.fire({
                    title: 'Error!',
                    text: 'Passwords do not match!',
                    icon: 'error',
                    confirmButtonText: 'OK'
                }).then(function() {
                    // Redirect after the SweetAlert is closed
                    window.location.href = 'index.php';
                });
            </script>
        ";
        exit;
    }

    // Hash the password before storing it in the database
    $hashedPassword = $password;
    // $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Prepare data for insertion
    $userData = [
        'email' => $email,
        'password' => $hashedPassword, // Store the hashed password
    ];
    // Call the create function from db.php to insert the user data into the database
    $newUserId = create('users', $userData);  // 'users' is the table name in your database

    // Check if user was created successfully
    if ($newUserId) {
        // Display success message using SweetAlert and redirect to index.php after dismiss
        echo "
            <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
            <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
            <script>
                Swal.fire({
                    title: 'Success!',
                    text: 'User created successfully! User ID: $newUserId',
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(function() {
                localStorage.setItem('email', '$email');
                    // Redirect after the SweetAlert is closed
                    window.location.href = 'index.php';
                });
            </script>
        ";
    } else {
        // Display error message using SweetAlert and redirect to index.php after dismiss
        echo "
            <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
            <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
            <script>
                Swal.fire({
                    title: 'Error!',
                    text: 'Error creating user.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                }).then(function() {
                    // Redirect after the SweetAlert is closed
                    window.location.href = 'index.php';
                });
            </script>
        ";
    }
}
?>
