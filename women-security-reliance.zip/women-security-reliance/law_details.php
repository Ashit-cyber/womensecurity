<?php
// Database connection configuration
$servername = "localhost";
$username = "root";  // Default for XAMPP
$password = "";      // Default for XAMPP (set your password if you changed it)
$dbname = "womenSecurity"; // Replace with your database name

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the 'id' from the URL
$id = isset($_GET['id']) ? $_GET['id'] : 0;

// Fetch the course data from the database based on the 'id'
$sql = "SELECT * FROM laws WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);  // 'i' means the parameter is an integer
$stmt->execute();
$result = $stmt->get_result();

// Check if a result was found
if ($result->num_rows > 0) {
    // Fetch the data
    $row = $result->fetch_assoc();
    $title = $row['title'];
    $short_description = $row['short_description'];
    $description = $row['description'];
} else {
    // Handle the case where no data is found
    $title = "Post Not Found";
    $short_description = "Sorry, the post you are looking for does not exist.";
    $description = "Please try another post.";
}

// Close the database connection
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?php echo htmlspecialchars($title); ?>
    </title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KyZXEJf+Xf5Fq1fQhl+aDbXTw93U/hgVeGvqG7cz7/tf07VjfwB4yC0IQj0O0XQ0" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body {
        background-color: #f7f7f7;
        font-family: 'Arial', sans-serif;
    }

    .blog-header {
        background-color: #28be97;
        color: white;
        padding: 50px;
    }

    .blog-header h1 {
        font-size: 3.5rem;
    }

    .blog-header p {
        font-size: 1.25rem;
    }

    .blog-content {
        background-color: white;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .blog-content h3 {
        font-size: 2rem;
        color: #333;
        margin-bottom: 20px;
    }

    .blog-content p {
        font-size: 1.125rem;
        line-height: 1.6;
        color: #555;
    }

    .blog-footer {
        background-color: #28be97;
        color: white;
        padding: 20px 0;
        text-align: center;
    }

    .blog-footer a {
        color: white;
        text-decoration: none;
        font-weight: bold;
    }
    </style>
</head>

<body>
    <div>
        <!-- Blog Header -->
        <div class="row blog-header text-center">
            <div class="col-12">
                <h1>
                    <?php echo htmlspecialchars($title); ?>
                </h1>
                <p class="lead">
                    <?php echo htmlspecialchars($short_description); ?>
                </p>
            </div>
        </div>

        <!-- Blog Content -->
        <div class="row justify-content-center">
            <div class="col-12 col-md-8">
                <!-- Blog Description -->
                <div class="blog-content">
                    <h3>
                        <?php echo htmlspecialchars($title); ?>
                    </h3>
                    <p>
                        <?php echo htmlspecialchars($description); ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Blog Footer -->
    <div class="blog-footer">
        <p><a href="#">Back to Top</a></p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-pzjw8f+ua7Kw1TIq0Jv9pmb5a8b27V+h9P36jsbm5mMm7VcBdWrwF4IW3d2cQ4tw" crossorigin="anonymous">
    </script>
</body>

</html>