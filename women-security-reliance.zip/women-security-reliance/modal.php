<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modal Example</title>

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- jQuery (for easier DOM manipulation) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

</head>
<body>

<!-- Button to open the modal -->
<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#authModal">
    Open Modal
</button>

<!-- Modal -->
<div class="modal fade" id="authModal" tabindex="-1" aria-labelledby="authModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="authModalLabel">Authentication</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <!-- Buttons to switch between Login and Sign Up -->
        <div class="d-flex justify-content-between mb-3">
            <button id="loginBtn" class="btn btn-primary w-48">Login</button>
            <button id="signupBtn" class="btn btn-outline-primary w-48">Sign Up</button>
        </div>

        <!-- Login Form (Visible by default) -->
        <div id="loginForm">
            <form>
                <div class="mb-3">
                    <label for="loginEmail" class="form-label">Email address</label>
                    <input type="email" class="form-control" id="loginEmail" required>
                </div>
                <div class="mb-3">
                    <label for="loginPassword" class="form-label">Password</label>
                    <input type="password" class="form-control" id="loginPassword" required>
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
        </div>

        <!-- Sign Up Form (Hidden by default) -->
        <div id="signupForm" class="d-none">
            <form>
                <div class="mb-3">
                    <label for="signupEmail" class="form-label">Email address</label>
                    <input type="email" class="form-control" id="signupEmail" required>
                </div>
                <div class="mb-3">
                    <label for="signupPassword" class="form-label">Password</label>
                    <input type="password" class="form-control" id="signupPassword" required>
                </div>
                <div class="mb-3">
                    <label for="signupConfirmPassword" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="signupConfirmPassword" required>
                </div>
                <button type="submit" class="btn btn-primary">Sign Up</button>
            </form>
        </div>

      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS and dependencies -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

<script>
    $(document).ready(function() {
        // Show login form by default
        $('#signupForm').addClass('d-none');
        
        // When the login button is clicked, show login form and hide signup form
        $('#loginBtn').on('click', function() {
            $('#loginForm').removeClass('d-none');
            $('#signupForm').addClass('d-none');
            $('#loginBtn').addClass('btn-primary').removeClass('btn-outline-primary');
            $('#signupBtn').addClass('btn-outline-primary').removeClass('btn-primary');
        });
        
        // When the signup button is clicked, show signup form and hide login form
        $('#signupBtn').on('click', function() {
            $('#signupForm').removeClass('d-none');
            $('#loginForm').addClass('d-none');
            $('#signupBtn').addClass('btn-primary').removeClass('btn-outline-primary');
            $('#loginBtn').addClass('btn-outline-primary').removeClass('btn-primary');
        });
    });
</script>

</body>
</html>
