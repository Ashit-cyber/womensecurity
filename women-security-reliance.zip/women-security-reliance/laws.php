<?php 
// Database connection
$servername = "localhost";
$username = "root";  // Default for XAMPP
$password = "";      // Default for XAMPP (set your password if you changed it)
$dbname = "womenSecurity"; // Replace with your database name
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch laws from the database
$sql = "SELECT * FROM laws"; // Replace 'laws' with your actual table name
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Women’s Security and Its Reliance</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KyZXEJf+Xf5Fq1fQhl+aDbXTw93U/hgVeGvqG7cz7/tf07VjfwB4yC0IQj0O0XQ0" crossorigin="anonymous">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <style>
    body {
        background-color: #f7f7f7;
        font-family: 'Arial', sans-serif;
    }

    .blog-header {
        background-color: #28be97;
        color: white;
        padding: 50px;
    }

    .blog-header h1 {
        font-size: 3.5rem;
    }

    .blog-header p {
        font-size: 1.25rem;
    }

    .blog-content {
        background-color: white;
        padding: 30px;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    .blog-content h3 {
        font-size: 2rem;
        color: #333;
        margin-bottom: 20px;
    }

    .blog-content p {
        font-size: 1.125rem;
        line-height: 1.6;
        color: #555;
    }

    .blog-footer {
        background-color: #28be97;
        color: white;
        padding: 20px 0;
        text-align: center;
    }

    .blog-footer a {
        color: white;
        text-decoration: none;
        font-weight: bold;
    }

    .card {
        margin-bottom: 20px;
    }

    .card-title {
        font-size: 1.5rem;
    }

    .card-text {
        font-size: 1.125rem;
        color: #555;
    }

    .card .title {
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 2;
        /* Limits the text to 2 lines */
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: normal;
        /* Ensure the text wraps correctly */
    }
    </style>
</head>

<body>
    <div>
        <!-- Blog Header -->
        <div class="row blog-header text-center">
            <div class="col-12">
                <h1>
                    Women Laws
                </h1>
                <p class="lead px-5">
                    An Examination of Legal Provisions for Women
                </p>
            </div>
        </div>

        <!-- Blog Content -->
        <div class="container">
            <div class="row">
                <?php 
                if ($result->num_rows > 0) {
                    // Loop through all laws and display them in cards
                    $counter = 0; // Counter to manage rows of 3 cards
                    while($row = $result->fetch_assoc()) {
                        // Get title, short description, and law ID
                        $law_title = $row['title'];  // Assuming 'title' is a column
                        $short_description = $row['short_description'];  // Assuming 'short_description' is a column
                        $law_id = $row['id'];  // Assuming 'id' is the unique identifier for each law

                        // Start a new row after every 3 cards
                        if ($counter % 3 == 0 && $counter > 0) {
                            echo "</div><div class='row'>"; // Close the previous row and start a new one
                        }

                        // Display a card for each law
                        echo "
                        <div class='col-xs-12 col-sm-6 col-md-6 col-lg-4'>
                            <div class='card text-center px-5 py-4 my-5'>
                                <div class='icon mb-3'>
                                    <i class='fa-solid fa-user-graduate'></i> <!-- Icon placeholder, replace as needed -->
                                </div>
                                <h3 class='title mb-5'>$law_title</h3>
                                <p class='content mb-3'>
                                    $short_description
                                </p>
                                <b class='content mb-3'>
                                    <!-- Add any additional info here if needed, like law fees or extra details -->
                                </b>
                                <div class='button-container text-center'>
                                    <a href='law_details.php?id=$law_id' class='btn btn-success px-5 py-2'>Read More</a>
                                </div>
                            </div>
                        </div>
                        ";

                        

                        $counter++; // Increment the counter
                    }
                } else {
                    echo "<p>No laws found.</p>";
                }
                ?>
            </div>
        </div>
    </div>

    <!-- Blog Footer -->
    <div class="blog-footer">
        <p><a href="#">Back to Top</a></p>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-pzjw8f+ua7Kw1TIq0Jv9pmb5a8b27V+h9P36jsbm5mMm7VcBdWrwF4IW3d2cQ4tw" crossorigin="anonymous">
    </script>
</body>

</html>

<?php
$conn->close();  // Close the database connection
?>