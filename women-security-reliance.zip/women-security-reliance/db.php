<?php
// db.php - Contains functions for CRUD operations

// Database connection settings
$servername = "localhost";
$username = "root";  // Default for XAMPP
$password = "";      // Default for XAMPP (set your password if you changed it)
$dbname = "womenSecurity"; // Replace with your database name
$port = 3306; // Default MySQL port, change if necessary

// Create a connection
function connect() {
    global $servername, $username, $password, $dbname, $port;
    
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    
    // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } else {
            // echo "Connected successfully to the database!";
        }
    
    return $conn;
}
connect();

// CREATE - Insert a new record
function create($table, $data) {
    $servername = "localhost";
$username = "root";  // Default for XAMPP
$password = "";      // Default for XAMPP (set your password if you changed it)
$dbname = "womenSecurity"; // Replace with your database name
$port = 3306; // Default MySQL port, change if necessary
    // $conn = connect();
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    
    // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        } else {
            echo "loading...";
        }
    // Assuming data is an associative array, e.g., ['name' => 'John', 'age' => 25]
    $columns = implode(", ", array_keys($data));
    $values = implode("', '", array_values($data));
    
    $sql = "INSERT INTO $table ($columns) VALUES ('$values')";
    // echo $sql;
    if ($conn->query($sql) === TRUE) {
        return $conn->insert_id;  // Return last inserted ID
    } else {
        return "Error: " . $conn->error;
    }
    
    $conn->close();
}

// READ - Fetch records from a table
function read($table, $conditions = "") {
    $servername = "localhost";
    $username = "root";  // Default for XAMPP
    $password = "";      // Default for XAMPP (set your password if you changed it)
    $dbname = "womenSecurity"; // Replace with your database name
    $port = 3306; // Default MySQL port, change if necessary
    $conn = new mysqli($servername, $username, $password, $dbname, $port);
    $sql = "SELECT * FROM $table";
    
    if ($conditions) {
        $sql .= " WHERE $conditions";
    }
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $data = [];
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        return $data;
    } else {
        return "No results found.";
    }
    
    $conn->close();
}

// READ ONE - Fetch a single record from a table
function readOne($table, $conditions) {
    $servername = "localhost";
    $username = "root";  // Default for XAMPP
    $password = "";      // Default for XAMPP (set your password if you changed it)
    $dbname = "womenSecurity"; // Replace with your database name
    $port = 3306; // Default MySQL port, change if necessary
        // $conn = connect();
        $conn = new mysqli($servername, $username, $password, $dbname, $port);
    // Add the condition for WHERE clause
    $sql = "SELECT * FROM $table WHERE $conditions LIMIT 1"; // LIMIT 1 ensures only one record is fetched
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        // Fetch the first row (since we limited it to 1)
        return $result->fetch_assoc();
    } else {
        return null; // Return null if no record found
    }
    
    $conn->close();
}

// UPDATE - Update a record in the table
function update($table, $data, $conditions) {
    $conn = connect();
    
    $set = "";
    foreach ($data as $column => $value) {
        $set .= "$column = '$value', ";
    }
    
    $set = rtrim($set, ", ");
    
    $sql = "UPDATE $table SET $set WHERE $conditions";
    
    if ($conn->query($sql) === TRUE) {
        return "Record updated successfully";
    } else {
        return "Error: " . $conn->error;
    }
    
    $conn->close();
}

// DELETE - Delete a record from the table
function delete($table, $conditions) {
    $conn = connect();
    
    $sql = "DELETE FROM $table WHERE $conditions";
    
    if ($conn->query($sql) === TRUE) {
        return "Record deleted successfully";
    } else {
        return "Error: " . $conn->error;
    }
    
    $conn->close();
}

?>
