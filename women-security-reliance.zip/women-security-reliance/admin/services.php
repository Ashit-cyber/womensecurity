<?php 
session_start();

// Check if the user is logged in
if(!$_SESSION['user_email']){
    echo "
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
    <script>
        Swal.fire({
            title: 'Error!',
            text: 'Unauthorized!',
            icon: 'error',
            confirmButtonText: 'OK'
        }).then(function() {
            window.location.href = 'login.html';
        });
    </script>";
    exit();
}

function read($table, $conditions = "") {
    $servername = "localhost";
    $username = "root";  // Default for XAMPP
    $password = "";      // Default for XAMPP (set your password if you changed it)
    $dbname = "womenSecurity"; // Replace with your database name
    $conn = new mysqli($servername, $username, $password, $dbname);

    $sql = "SELECT * FROM $table";
    
    if ($conditions) {
        $sql .= " WHERE $conditions";
    }
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $data = [];
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        return $data;
    } else {
        return [];
    }
    
    $conn->close();
}

// Handle delete request for services
if (isset($_POST['delete_id'])) {
    $serviceId = $_POST['delete_id'];
    
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "womenSecurity";
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Delete service by ID
    $sql = "DELETE FROM services WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $serviceId);
    
    if ($stmt->execute()) {
        echo "success"; // Respond with success
    } else {
        echo "error"; // Respond with error
    }
    
    $stmt->close();
    $conn->close();
    exit();
}

// Handle update request for services
if (isset($_POST['update_id'])) {
    $updateId = $_POST['update_id'];
    $title = $_POST['title'];
    $shortDescription = $_POST['short_description'];
    $description = $_POST['description'];
    $fees = $_POST['fees']; // Get the fees value

    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "womenSecurity";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Update query
    $sql = "UPDATE services SET title = ?, short_description = ?, description = ?, fees = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssdi", $title, $shortDescription, $description, $fees, $updateId);
    
    if ($stmt->execute()) {
        echo "success"; // Respond with success
    } else {
        echo "error"; // Respond with error
    }
    
    $stmt->close();
    $conn->close();
    exit();
}

?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard | Service List</title>
    <link href="assets/vendor/fontawesome/css/fontawesome.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/solid.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/brands.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/master.css" rel="stylesheet">
    <link href="assets/vendor/flagiconcss/css/flag-icon.min.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
</head>

<body>
    <div class="wrapper">
        <?php include('./sidebar.php'); ?>

        <div class="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 page-header">
                        <div class="page-pretitle">Services</div>
                        <h2 class="page-title">Manage Services</h2>
                    </div>
                </div>
                <div class="col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <span>All Services</span>
                            <a href="add-services.php" class="btn btn-primary">Add Service</a>
                        </div>

                        <div class="card-body">
                            <table class="table table-hover" id="dataTables-example" width="100%">
                                <thead>
                                    <tr>
                                        <th>Title</th>
                                        <th>Short Description</th>
                                        <th>Fees</th> <!-- Added Fees Column -->
                                        <th>Edit</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $data = read('services');
                                    foreach ($data as $row) {
                                        echo "
                                        <tr>
                                            <td>". $row['title'] ."</td>
                                            <td>". $row['short_description'] ."</td>
                                            <td>". $row['fees'] ."</td> <!-- Display Fees Here -->
                                            <td><i class='fa-solid fa-pen edit-icon' data-id='".$row['id']."' data-title='".$row['title']."' data-short-description='".$row['short_description']."' data-description='".$row['description']."' data-fees='".$row['fees']."' style='cursor:pointer;'></i></td>
                                            <td><i class='fa-solid fa-trash delete-icon' data-id='".$row['id']."' style='cursor:pointer;'></i></td>
                                        </tr>
                                        ";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Update -->
    <div class="modal fade" id="updateModal" tabindex="-1" role="dialog" aria-labelledby="updateModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="updateModalLabel">Update Service</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="updateForm">
                    <div class="modal-body">
                        <input type="hidden" id="update_id" name="update_id">
                        <div class="form-group">
                            <label for="title">Title</label>
                            <input type="text" class="form-control" id="title" name="title" required>
                        </div>
                        <div class="form-group">
                            <label for="short_description">Short Description</label>
                            <input type="text" class="form-control" id="short_description" name="short_description"
                                required>
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea class="form-control" id="description" name="description" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="fees">Fees</label>
                            <input type="number" step="0.01" class="form-control" id="fees" name="fees" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
    $(document).ready(function() {
        // Handle delete icon click for services
        $(".delete-icon").click(function() {
            var serviceId = $(this).data("id");

            // Show confirmation before deletion
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Yes, delete it!',
                cancelButtonText: 'No, keep it'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Send delete request via AJAX
                    $.ajax({
                        url: '', // Same file to handle the request
                        type: 'POST',
                        data: {
                            delete_id: serviceId
                        },
                        success: function(response) {
                            if (response == "success") {
                                Swal.fire('Deleted!',
                                        'The service has been deleted.', 'success')
                                    .then(function() {
                                        location
                                    .reload(); // Reload the page after deletion
                                    });
                            } else {
                                Swal.fire('Error!',
                                    'There was an error deleting the service.',
                                    'error');
                            }
                        },
                        error: function() {
                            Swal.fire('Error!',
                                'There was an error processing your request.',
                                'error');
                        }
                    });
                }
            });
        });

        // Handle edit icon click for services
        $(".edit-icon").click(function() {
            var serviceId = $(this).data("id");
            var title = $(this).data("title");
            var shortDescription = $(this).data("short-description");
            var description = $(this).data("description");
            var fees = $(this).data("fees"); // Get the fees value

            // Populate the modal fields
            $("#update_id").val(serviceId);
            $("#title").val(title);
            $("#short_description").val(shortDescription);
            $("#description").val(description);
            $("#fees").val(fees); // Set the fees field in the modal

            // Show the modal
            $("#updateModal").modal("show");
        });

        // Handle form submission for service update
        $("#updateForm").submit(function(e) {
            e.preventDefault();
            var formData = $(this).serialize();

            $.ajax({
                url: '', // Same file
                type: 'POST',
                data: formData,
                success: function(response) {
                    if (response == "success") {
                        Swal.fire('Updated!', 'The service has been updated.', 'success')
                            .then(function() {
                                // Close the modal
                                $("#updateModal").modal("hide");
                                location.reload();
                            });
                    } else {
                        Swal.fire('Error!', 'There was an error updating the service.',
                            'error');
                    }
                },
                error: function() {
                    Swal.fire('Error!', 'There was an error processing your request.',
                        'error');
                }
            });
        });
    });
    </script>

    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/chartsjs/Chart.min.js"></script>
    <script src="assets/js/dashboard-charts.js"></script>
    <script src="assets/js/script.js"></script>
</body>

</html>