<?php
session_start();

// Database connection
$servername = "localhost"; // XAMPP default server
$username = "root"; // XAMPP default username
$password = ""; // XAMPP default password
$dbname = "womenSecurity"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare the SQL query to prevent SQL injection
    $sql = "SELECT * FROM admin WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    // Check if the user exists
    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();

        // Verify the password (use password_verify if hashed)
        if ($password === $user['password']) {
            // Set session variables and redirect to dashboard
            $_SESSION['loggedin'] = true;
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_email'] = $user['email'];
        
            echo "loading...";
            echo "
                <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
                <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
                <script>
                    Swal.fire({
                        title: 'Success!',
                        text: 'Login successful!',
                        icon: 'success',
                        confirmButtonText: 'OK'
                    }).then(function() {
                        
                        // Redirect to the home page (index.php) after the SweetAlert is closed
                        window.location.href = 'index.php';
                    });
                </script>
            ";
            // Redirect to the dashboard page or wherever you want
            // header("Location: index.html");
            exit();
        } else {
            // Incorrect password
            echo "loading...";
            echo "
            <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
            <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
            <script>
                Swal.fire({
                    title: 'Error!',
                    text: 'Incorrect password!',
                    icon: 'error',
                    confirmButtonText: 'OK'
                }).then(function() {
                    // Redirect back to the login page after the SweetAlert is closed
                    window.location.href = 'login.html';
                });
            </script>
        ";
        }
        
        
    } else {
        // No user found with this email
        echo "loading...";
        echo "
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
        <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
        <script>
            Swal.fire({
                title: 'Error!',
                text: 'No user found with that email.',
                icon: 'error',
                confirmButtonText: 'OK'
            }).then(function() {
                // Redirect back to the login page after the SweetAlert is closed
                window.location.href = 'login.html';
            });
        </script>
    ";
    }

    // Close the prepared statement
    $stmt->close();
}

// Close the database connection
$conn->close();
?>

<!-- HTML part to show the error message -->
<?php if (isset($error_message)): ?>
    <div class="alert alert-danger" role="alert">
        <?php echo $error_message; ?>
    </div>
<?php endif; ?>
