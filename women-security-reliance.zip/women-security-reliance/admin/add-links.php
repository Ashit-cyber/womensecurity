<?php 
session_start();

// Check if the user is logged in
if(!$_SESSION['user_email']){
    echo "
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
    <script>
        Swal.fire({
            title: 'Error!',
            text: 'Unauthorized!',
            icon: 'error',
            confirmButtonText: 'OK'
        }).then(function() {
            // Redirect back to the login page after the SweetAlert is closed
            window.location.href = 'login.html';
        });
    </script>";
    exit();
}

// Handle form submission to add a new link
if (isset($_POST['submit_link'])) {
    $title = $_POST['title'];
    $link = $_POST['link'];

    // Database connection
    $servername = "localhost";
    $username = "root";  // Default for XAMPP
    $password = "";      // Default for XAMPP (set your password if you changed it)
    $dbname = "womenSecurity"; // Replace with your database name
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert new link into the database
    $sql = "INSERT INTO youtube_links (title, link) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $title, $link);

    if ($stmt->execute()) {
        // Show SweetAlert success message and redirect after confirmation
        echo "loading...";
        echo "
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
        <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
        <script>
            Swal.fire({
                title: 'Success!',
                text: 'Data created successfully',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then(function() {
                
                // Redirect to the home page (index.php) after the SweetAlert is closed
                window.location.href = 'links.php';
            });
        </script>
    ";
    } else {
        // Show SweetAlert error message
        echo "loading...";
        echo "
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
        <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
        <script>
            Swal.fire({
                title: 'Error!',
                text: 'There was an error adding the link.',
                icon: 'error',
                confirmButtonText: 'OK'
            }).then(function() {
                
                // Redirect to the home page (index.php) after the SweetAlert is closed
                window.location.href = 'links.php';
            });
        </script>
       ";
    }

    $stmt->close();
    $conn->close();
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard | Add Link</title>
    <link href="assets/vendor/fontawesome/css/fontawesome.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/solid.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/brands.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/master.css" rel="stylesheet">
    <link href="assets/vendor/flagiconcss/css/flag-icon.min.css" rel="stylesheet">
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
</head>
<body>
    <div class="wrapper">
        <?php include('./sidebar.php'); ?>
        
        <div class="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 page-header">
                        <div class="page-pretitle">Links</div>
                        <h2 class="page-title">Add New Link</h2>
                    </div>
                </div>

                <!-- Create Link Form -->
                <div class="col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <span>Add New Link</span>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="" accept-charset="utf-8">
                                <div class="mb-3">
                                    <label for="title" class="form-label">Link Title</label>
                                    <input type="text" name="title" placeholder="Link Title" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <label for="link" class="form-label">Link URL</label>
                                    <input type="url" name="link" placeholder="Link URL" class="form-control" required>
                                </div>
                                <div class="mb-3">
                                    <input type="submit" name="submit_link" class="btn btn-primary" value="Add Link">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/chartsjs/Chart.min.js"></script>
    <script src="assets/js/dashboard-charts.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>
