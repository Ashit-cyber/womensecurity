<?php
if (isset($_POST['logout'])) {
    session_start();
    session_destroy();
    header("Location: login.html"); // Redirect to login page after logout
    exit();
}
?>
<nav id="sidebar" class="active">
    <div class="sidebar-header">
        <!-- <img src="assets/img/bootstraper-logo.png" alt="bootraper logo" class="app-logo"> -->
        <a class="navbar-brand" href="#">
            <!-- <img src="assets/imges/Logo.svg" alt="logo" width="150px"> -->
            <i class="fa-solid fa-venus" style="font-size: 20px; color: #22a17f;"></i>
            <span style="font-weight: 600;font-size: 20px;color: black;">Women <span
                    style="color: #22a17f;">Security</span></span>
        </a>
    </div>
    <ul class="list-unstyled components text-secondary">
        <li>
            <a href="index.php"><i class="fas fa-home"></i> Dashboard</a>
        </li>
        <li>
            <a href="users.php"><i class="fa-solid fa-user-group"></i> Users</a>
        </li>
        <li>
            <a href="links.php"><i class="fa-solid fa-link"></i> Links</a>
        </li>
        <li>
            <a href="cources.php"><i class="fa-solid fa-graduation-cap"></i> Cources</a>
        </li>
        <li>
            <a href="services.php"><i class="fa-solid fa-cogs"></i> Services</a>
        </li>
        <li>
            <a href="laws.php"><i class="fa-solid fa-gavel"></i> Laws</a>
        </li>
        <li>
            <a href="./admin.php"><i class="fa-solid fa-message"></i> Chat</a>
            <!-- <a href="./cha/admin.php" target="_blank"><i class="fa-solid fa-message"></i> Chat</a> -->
        </li>
        <!-- <li>
                    <a href="forms.html"><i class="fas fa-file-alt"></i> Forms</a>
                </li>
                <li>
                    <a href="tables.html"><i class="fas fa-table"></i> Tables</a>
                </li>
                <li>
                    <a href="charts.html"><i class="fas fa-chart-bar"></i> Charts</a>
                </li>
                <li>
                    <a href="icons.html"><i class="fas fa-icons"></i> Icons</a>
                </li>
                <li>
                    <a href="#uielementsmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle no-caret-down"><i class="fas fa-layer-group"></i> UI Elements</a>
                    <ul class="collapse list-unstyled" id="uielementsmenu">
                        <li>
                            <a href="ui-buttons.html"><i class="fas fa-angle-right"></i> Buttons</a>
                        </li>
                        <li>
                            <a href="ui-badges.html"><i class="fas fa-angle-right"></i> Badges</a>
                        </li>
                        <li>
                            <a href="ui-cards.html"><i class="fas fa-angle-right"></i> Cards</a>
                        </li>
                        <li>
                            <a href="ui-alerts.html"><i class="fas fa-angle-right"></i> Alerts</a>
                        </li>
                        <li>
                            <a href="ui-tabs.html"><i class="fas fa-angle-right"></i> Tabs</a>
                        </li>
                        <li>
                            <a href="ui-date-time-picker.html"><i class="fas fa-angle-right"></i> Date & Time Picker</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#authmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle no-caret-down"><i class="fas fa-user-shield"></i> Authentication</a>
                    <ul class="collapse list-unstyled" id="authmenu">
                        <li>
                            <a href="login.html"><i class="fas fa-lock"></i> Login</a>
                        </li>
                        <li>
                            <a href="signup.html"><i class="fas fa-user-plus"></i> Signup</a>
                        </li>
                        <li>
                            <a href="forgot-password.html"><i class="fas fa-user-lock"></i> Forgot password</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="#pagesmenu" data-bs-toggle="collapse" aria-expanded="false" class="dropdown-toggle no-caret-down"><i class="fas fa-copy"></i> Pages</a>
                    <ul class="collapse list-unstyled" id="pagesmenu">
                        <li>
                            <a href="blank.html"><i class="fas fa-file"></i> Blank page</a>
                        </li>
                        <li>
                            <a href="404.html"><i class="fas fa-info-circle"></i> 404 Error page</a>
                        </li>
                        <li>
                            <a href="500.html"><i class="fas fa-info-circle"></i> 500 Error page</a>
                        </li>
                    </ul>
                </li>
                <li>
                    <a href="users.html"><i class="fas fa-user-friends"></i>Users</a>
                </li>
                <li>
                    <a href="settings.html"><i class="fas fa-cog"></i>Settings</a>
                </li> -->
    </ul>
</nav>
<div id="body" class="active">
    <!-- navbar navigation component -->
    <nav class="navbar navbar-expand-lg navbar-white bg-white">
        <button type="button" id="sidebarCollapse" class="btn btn-light">
            <i class="fas fa-bars"></i><span></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="nav navbar-nav ms-auto">
                <li class="nav-item dropdown">
                    <div class="nav-dropdown">
                        <!-- <a href="#" id="nav1" class="nav-item nav-link dropdown-toggle text-secondary"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-link"></i> <span>Quick Links</span> <i style="font-size: .8em;"
                                class="fas fa-caret-down"></i>
                        </a> -->
                        <div class="dropdown-menu dropdown-menu-end nav-link-menu" aria-labelledby="nav1">
                            <ul class="nav-list">
                                <li><a href="" class="dropdown-item"><i class="fas fa-list"></i> Access Logs</a></li>
                                <div class="dropdown-divider"></div>
                                <li><a href="" class="dropdown-item"><i class="fas fa-database"></i> Back ups</a></li>
                                <div class="dropdown-divider"></div>
                                <li><a href="" class="dropdown-item"><i class="fas fa-cloud-download-alt"></i>
                                        Updates</a></li>
                                <div class="dropdown-divider"></div>
                                <li><a href="" class="dropdown-item"><i class="fas fa-user-shield"></i> Roles</a></li>
                            </ul>
                        </div>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <div class="nav-dropdown">
                        <a href="#" id="nav2" class="nav-item nav-link dropdown-toggle text-secondary"
                            data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user"></i> <span><?php echo $_SESSION['user_email']; ?></span> <i
                                style="font-size: .8em;" class="fas fa-caret-down"></i>
                        </a>
                        <div class="dropdown-menu dropdown-menu-end nav-link-menu">
                            <ul class="nav-list">
                                <!-- <li><a href="" class="dropdown-item"><i class="fas fa-address-card"></i> Profile</a>
                                </li>
                                <li><a href="" class="dropdown-item"><i class="fas fa-envelope"></i> Messages</a></li>
                                <li><a href="" class="dropdown-item"><i class="fas fa-cog"></i> Settings</a></li> -->
                                <div class="dropdown-divider"></div>
                                <form action="" method="POST">
                                    <button type="submit" name="logout" class="dropdown-item">
                                        <i class="fas fa-sign-out-alt"></i> Logout
                                    </button>
                                </form>
                            </ul>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </nav>