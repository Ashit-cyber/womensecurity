<?php 
session_start();
if(!$_SESSION['user_email']){
    echo "
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
    <script>
        Swal.fire({
            title: 'Error!',
            text: 'Unauthorized!',
            icon: 'error',
            confirmButtonText: 'OK'
        }).then(function() {
            // Redirect back to the login page after the SweetAlert is closed
            window.location.href = 'login.html';
        });
    </script>";
}
// if (isset($_POST['logout'])) {
//     session_start();
//     session_destroy();
//     header("Location: login.html"); // Redirect to login page after logout
//     exit();
// }
?>
<!doctype html>
<!-- 
* Bootstrap Simple Admin Template
* Version: 2.1
* Author: Alexis Luna
* Website: https://github.com/alexis-luna/bootstrap-simple-admin-template
-->
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard | Bootstrap Simple Admin Template</title>
    <link href="assets/vendor/fontawesome/css/fontawesome.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/solid.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/brands.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/master.css" rel="stylesheet">
    <link href="assets/vendor/flagiconcss/css/flag-icon.min.css" rel="stylesheet">
</head>

<body>
    <div class="wrapper">
        <?php
        include('./sidebar.php')
        ?>

        <!-- end of navbar navigation -->
        <div class="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 page-header">
                        <div class="page-pretitle">Overview</div>
                        <h2 class="page-title">Dashboard</h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-3 mt-3">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="icon-big text-center">
                                            <i class="teal fas fa-user-group"></i>
                                        </div>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="detail">
                                            <p class="detail-subtitle">Total users</p>
                                            <?php
                                            // Database connection parameters
                                            $servername = "localhost";
                                            $username = "root";  // Your database username (default for XAMPP is 'root')
                                            $password = "";      // Your database password (default for XAMPP is an empty string)
                                            $dbname = "womenSecurity";  // Replace with your database name

                                            // Create connection
                                            $conn = new mysqli($servername, $username, $password, $dbname);

                                            // Check connection
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }

                                            // SQL query to count total courses
                                            $sql = "SELECT COUNT(*) AS total_courses FROM users";  // Replace 'courses' with your table name

                                            // Execute the query
                                            $result = $conn->query($sql);

                                            // Check if the query returned any result
                                            if ($result->num_rows > 0) {
                                                // Fetch the result as an associative array
                                                $row = $result->fetch_assoc();
                                                $totalCourses = $row['total_courses'];  // Get the total number of courses
                                                echo '<span class="number">'.$totalCourses.'</span>';
                                            } else {
                                                echo '<span class="number">0</span>';
                                            }

                                            // Close the connection
                                            $conn->close();
                                            ?>


                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="footer">
                                    <hr />
                                    <div class="stats">
                                        <i class="fas fa-calendar"></i> For this Week
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-3 mt-3">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="icon-big text-center">
                                            <i class="teal fas fa-user-group"></i>
                                        </div>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="detail">
                                            <p class="detail-subtitle">Total services</p>
                                            <?php
                                            // Database connection parameters
                                            $servername = "localhost";
                                            $username = "root";  // Your database username (default for XAMPP is 'root')
                                            $password = "";      // Your database password (default for XAMPP is an empty string)
                                            $dbname = "womenSecurity";  // Replace with your database name

                                            // Create connection
                                            $conn = new mysqli($servername, $username, $password, $dbname);

                                            // Check connection
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }

                                            // SQL query to count total courses
                                            $sql = "SELECT COUNT(*) AS total_courses FROM services";  // Replace 'courses' with your table name

                                            // Execute the query
                                            $result = $conn->query($sql);

                                            // Check if the query returned any result
                                            if ($result->num_rows > 0) {
                                                // Fetch the result as an associative array
                                                $row = $result->fetch_assoc();
                                                $totalCourses = $row['total_courses'];  // Get the total number of courses
                                                echo '<span class="number">'.$totalCourses.'</span>';
                                            } else {
                                                echo '<span class="number">0</span>';
                                            }

                                            // Close the connection
                                            $conn->close();
                                            ?>


                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="footer">
                                    <hr />
                                    <div class="stats">
                                        <i class="fas fa-calendar"></i> For this Week
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-3 mt-3">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="icon-big text-center">
                                            <i class="teal fas fa-link"></i>
                                        </div>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="detail">
                                            <p class="detail-subtitle">Total links</p>
                                            <?php
                                            // Database connection parameters
                                            $servername = "localhost";
                                            $username = "root";  // Your database username (default for XAMPP is 'root')
                                            $password = "";      // Your database password (default for XAMPP is an empty string)
                                            $dbname = "womenSecurity";  // Replace with your database name

                                            // Create connection
                                            $conn = new mysqli($servername, $username, $password, $dbname);

                                            // Check connection
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }

                                            // SQL query to count total courses
                                            $sql = "SELECT COUNT(*) AS total_courses FROM youtube_links";  // Replace 'courses' with your table name

                                            // Execute the query
                                            $result = $conn->query($sql);

                                            // Check if the query returned any result
                                            if ($result->num_rows > 0) {
                                                // Fetch the result as an associative array
                                                $row = $result->fetch_assoc();
                                                $totalCourses = $row['total_courses'];  // Get the total number of courses
                                                echo '<span class="number">'.$totalCourses.'</span>';
                                            } else {
                                                echo '<span class="number">0</span>';
                                            }

                                            // Close the connection
                                            $conn->close();
                                            ?>


                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="footer">
                                    <hr />
                                    <div class="stats">
                                        <i class="fas fa-calendar"></i> For this Week
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-md-6 col-lg-3 mt-3">
                        <div class="card">
                            <div class="content">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <div class="icon-big text-center">
                                            <i class="teal fas fa-graduation-cap"></i>
                                        </div>
                                    </div>
                                    <div class="col-sm-8">
                                        <div class="detail">
                                            <p class="detail-subtitle">Total courses</p>
                                            <?php
                                            // Database connection parameters
                                            $servername = "localhost";
                                            $username = "root";  // Your database username (default for XAMPP is 'root')
                                            $password = "";      // Your database password (default for XAMPP is an empty string)
                                            $dbname = "womenSecurity";  // Replace with your database name

                                            // Create connection
                                            $conn = new mysqli($servername, $username, $password, $dbname);

                                            // Check connection
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }

                                            // SQL query to count total courses
                                            $sql = "SELECT COUNT(*) AS total_courses FROM courses";  // Replace 'courses' with your table name

                                            // Execute the query
                                            $result = $conn->query($sql);

                                            // Check if the query returned any result
                                            if ($result->num_rows > 0) {
                                                // Fetch the result as an associative array
                                                $row = $result->fetch_assoc();
                                                $totalCourses = $row['total_courses'];  // Get the total number of courses
                                                echo '<span class="number">'.$totalCourses.'</span>';
                                            } else {
                                                echo '<span class="number">0</span>';
                                            }

                                            // Close the connection
                                            $conn->close();
                                            ?>


                                        </div>
                                    </div>
                                </div>
                                <!-- <div class="footer">
                                    <hr />
                                    <div class="stats">
                                        <i class="fas fa-calendar"></i> For this Week
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                    <!-- counter secton end  -->
                    <div class="row mt-5 py-5" style="background: white">
                        <div class="col-md-12">
                            <h3 class="text-center my-2">Enrollments Data</h3>
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th class="text-center">User</th>
                                        <th class="text-center">Service Title</th> <!-- Service Title -->
                                        <th class="text-center">Address</th>
                                        <th class="text-center">Created At</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
        // Database connection parameters
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "womenSecurity";

        // Create connection
        $conn = new mysqli($servername, $username, $password, $dbname);

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // SQL query to get all enrollments and service title
        $sql = "SELECT e.id, e.user_id,e.name, s.title AS service_title, e.address, e.created_at
                FROM enrollments e
                JOIN services s ON e.service_id = s.id"; // Join with services table

        // Execute the query
        $result = $conn->query($sql);

        // Check if the query returned any results
        if ($result->num_rows > 0) {
            // Fetch and display each row of data
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td class='text-center'>" . $row['name'] . "</td>
                        <td class='text-center'>" . $row['service_title'] . "</td> <!-- Display service title -->
                        <td class='text-center'>" . $row['address'] . "</td>
                        <td class='text-center'>" . $row['created_at'] . "</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='5' class='text-center'>No enrollments found.</td></tr>";
        }

        // Close the connection
        $conn->close();
        ?>
                                </tbody>
                            </table>


                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    </div>
    <script src="assets/vendor/jquery/jquery.min.js"></script>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/chartsjs/Chart.min.js"></script>
    <script src="assets/js/dashboard-charts.js"></script>
    <script src="assets/js/script.js"></script>
</body>

</html>