<?php 
session_start();

// Check if the user is logged in
if(!$_SESSION['user_email']){
    echo "
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
    <script>
        Swal.fire({
            title: 'Error!',
            text: 'Unauthorized!',
            icon: 'error',
            confirmButtonText: 'OK'
        }).then(function() {
            // Redirect back to the login page after the SweetAlert is closed
            window.location.href = 'login.html';
        });
    </script>";
    exit();
}

function read($table, $conditions = "") {
    $servername = "localhost";
    $username = "root";  // Default for XAMPP
    $password = "";      // Default for XAMPP (set your password if you changed it)
    $dbname = "womenSecurity"; // Replace with your database name
    $conn = new mysqli($servername, $username, $password, $dbname);

    $sql = "SELECT * FROM $table";
    
    if ($conditions) {
        $sql .= " WHERE $conditions";
    }
    
    $result = $conn->query($sql);
    
    if ($result->num_rows > 0) {
        $data = [];
        while($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
        return $data;
    } else {
        return [];
    }
    
    $conn->close();
}

// Handle delete request
if (isset($_POST['delete_id'])) {
    $userId = $_POST['delete_id'];
    
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "womenSecurity";
    $conn = new mysqli($servername, $username, $password, $dbname);
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    // Delete user by ID
    $sql = "DELETE FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    
    if ($stmt->execute()) {
        echo "success"; // Respond with success
    } else {
        echo "error"; // Respond with error
    }
    
    $stmt->close();
    $conn->close();
    exit();
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard | User List</title>
    <link href="assets/vendor/fontawesome/css/fontawesome.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/solid.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/brands.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/master.css" rel="stylesheet">
    <link href="assets/vendor/flagiconcss/css/flag-icon.min.css" rel="stylesheet">
    
    <!-- <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js"></script> -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
            <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
</head>
<body>
    <div class="wrapper">
        <?php include('./sidebar.php'); ?>
        
        <div class="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 page-header">
                        <div class="page-pretitle">Users</div>
                        <h2 class="page-title">User List</h2>
                    </div>
                </div>
                <div class="col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">Registered User List</div>
                        <div class="card-body">
                            <table class="table table-hover" id="dataTables-example" width="100%">
                                <thead>
                                    <tr>
                                        <th>Email</th>
                                        <th>Delete</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                $data = read('users');
                                foreach ($data as $row) {
                                    echo "
                                    <tr>
                                        <td>". $row['email'] ."</td>
                                        <td><i class='fa-solid fa-trash delete-icon' data-id='".$row['id']."' style='cursor:pointer;'></i></td>
                                    </tr>
                                    ";
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            // Handle delete icon click
            $(".delete-icon").click(function() {
                var userId = $(this).data("id");

                // Show SweetAlert confirmation
                Swal.fire({
                    title: 'Are you sure?',
                    text: "You won't be able to revert this!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Make an AJAX request to delete the user
                        $.ajax({
                            url: '',  // Same file
                            type: 'POST',
                            data: { delete_id: userId },
                            success: function(response) {
                                if (response == "success") {
                                    // Remove the deleted row from the table
                                    $("i[data-id='" + userId + "']").closest("tr").remove();
                                    Swal.fire('Deleted!', 'The user has been deleted.', 'success');
                                } else {
                                    Swal.fire('Error!', 'There was an error deleting the user.', 'error');
                                }
                            },
                            error: function() {
                                Swal.fire('Error!', 'There was an error processing your request.', 'error');
                            }
                        });
                    }
                });
            });
        });
    </script>

    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/chartsjs/Chart.min.js"></script>
    <script src="assets/js/dashboard-charts.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html>
