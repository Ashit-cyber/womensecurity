<?php 
session_start();

// Check if the user is logged in
if(!$_SESSION['user_email']){
    echo "
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
    <script>
        Swal.fire({
            title: 'Error!',
            text: 'Unauthorized!',
            icon: 'error',
            confirmButtonText: 'OK'
        }).then(function() {
            window.location.href = 'login.html';
        });
    </script>";
    exit();
}

// Handle form submission to add a new service
if (isset($_POST['submit_service'])) {
    $title = $_POST['title'];
    $short_description = $_POST['short_description'];
    $description = $_POST['description'];
    $fees = $_POST['fees'];  // Get the fees value from the form

    // Database connection
    $servername = "localhost";
    $username = "root";  // Default for XAMPP
    $password = "";      // Default for XAMPP (set your password if you changed it)
    $dbname = "womenSecurity"; // Replace with your database name
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Insert new service into the database
    $sql = "INSERT INTO services (title, short_description, description, fees) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssd", $title, $short_description, $description, $fees);  // 'd' for decimal

    if ($stmt->execute()) {
        // Show SweetAlert success message and redirect after confirmation
        echo "loading...";
        echo "
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
        <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
        <script>
            Swal.fire({
                title: 'Success!',
                text: 'Service added successfully',
                icon: 'success',
                confirmButtonText: 'OK'
            }).then(function() {
                window.location.href = 'services.php';
            });
        </script>
    ";
    } else {
        // Show SweetAlert error message
        echo "loading...";
        echo "
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
        <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
        <script>
            Swal.fire({
                title: 'Error!',
                text: 'There was an error adding the service.',
                icon: 'error',
                confirmButtonText: 'OK'
            }).then(function() {
                window.location.href = 'services.php';
            });
        </script>
       ";
    }

    $stmt->close();
    $conn->close();
}
?>
<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Dashboard | Add Service</title>
    <link href="assets/vendor/fontawesome/css/fontawesome.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/solid.min.css" rel="stylesheet">
    <link href="assets/vendor/fontawesome/css/brands.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/master.css" rel="stylesheet">
    <link href="assets/vendor/flagiconcss/css/flag-icon.min.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.js'></script>
    <link rel='stylesheet' href='https://cdn.jsdelivr.net/npm/sweetalert2@11.3.1/dist/sweetalert2.min.css'>
</head>

<body>
    <div class="wrapper">
        <?php include('./sidebar.php'); ?>

        <div class="content">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 page-header">
                        <div class="page-pretitle">Services</div>
                        <h2 class="page-title">Add New Service</h2>
                    </div>
                </div>

                <!-- Create Service Form -->
                <div class="col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <span>Add New Service</span>
                        </div>
                        <div class="card-body">
                            <form method="POST" action="" accept-charset="utf-8">
                                <div class="mb-3">
                                    <label for="title" class="form-label">Service Title</label>
                                    <input type="text" name="title" placeholder="Service Title" class="form-control"
                                        required>
                                </div>
                                <div class="mb-3">
                                    <label for="short_description" class="form-label">Short Description</label>
                                    <textarea name="short_description" placeholder="Short Description"
                                        class="form-control" required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="description" class="form-label">Description</label>
                                    <textarea name="description" placeholder="Description" class="form-control"
                                        required></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="fees" class="form-label">Fees</label>
                                    <input type="number" name="fees" placeholder="Fees" class="form-control" step="0.01"
                                        required>
                                </div>
                                <div class="mb-3">
                                    <input type="submit" name="submit_service" class="btn btn-primary"
                                        value="Add Service">
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/chartsjs/Chart.min.js"></script>
    <script src="assets/js/dashboard-charts.js"></script>
    <script src="assets/js/script.js"></script>
</body>

</html>