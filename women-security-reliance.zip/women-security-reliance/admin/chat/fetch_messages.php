<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "womensecurity";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$userId = isset($_GET['userId']) ? $_GET['userId'] : 0;  // Get the userId from query parameter
$sql = "SELECT * FROM messages WHERE user_id = $userId ORDER BY timestamp ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        if ($row['sender'] == 'admin') {
            echo "<div class='message admin-message'><strong>Admin:</strong> " . $row['message'] . "</div>";
        } else {
            echo "<div class='message user-message'><strong>User:</strong> " . $row['message'] . "</div>";
        }
    }
} else {
    echo "No messages";
}

$conn->close();
?>
