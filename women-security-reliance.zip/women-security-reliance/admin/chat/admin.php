<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat App - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #chat-box {
            height: 300px;
            overflow-y: scroll;
            margin-bottom: 10px;
            border: 1px solid #ddd;
        }
        .message {
            padding: 5px;
            margin-bottom: 5px;
        }
        .user-message {
            background-color: #f1f1f1;
        }
        .admin-message {
            background-color: #d1e7dd;
        }
        .user-list {
            margin-bottom: 20px;
        }
        .user-item {
            cursor: pointer;
            padding: 10px;
            background-color: #f8f9fa;
            margin: 5px 0;
            border-radius: 5px;
        }
        .user-item:hover {
            background-color: #e2e6ea;
        }
    </style>
</head>
<body>
<div class="container mt-5">
        <h2>Admin Chat</h2>
        <div class="row">
            <!-- User List (Left Side) -->
            <div class="col-md-4">
                <div class="user-list">
                    <h4>Users</h4>
                    <div id="user-list"></div>
                </div>
            </div>
            
            <!-- Chat Box (Right Side) -->
            <div class="col-md-8">
                <div id="chat-box" class="mb-3"></div>
                <input type="text" id="message" class="form-control" placeholder="Type your message...">
                <button class="btn btn-primary mt-2" id="sendMessage">Send</button>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        var currentUserId = null;  // Store the current selected user ID for chat
        var messageInterval = null;  // Store the interval reference for auto-fetching messages

        // Fetch and display the list of users
        function fetchUsers() {
            $.ajax({
                url: 'fetch_users.php',
                method: 'GET',
                success: function(data) {
                    $('#user-list').html(data);
                }
            });
        }

        // Fetch messages of the selected user
        function fetchMessages(userId) {
            $.ajax({
                url: 'fetch_messages.php',
                method: 'GET',
                data: { userId: userId },  // Pass the selected user's ID
                success: function(data) {
                    $('#chat-box').html(data);
                    $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight);  // Scroll to the bottom of the chat
                }
            });
        }

        // Set interval to auto-fetch messages every 2 seconds
        function startAutoFetchMessages(userId) {
            // If an interval already exists, clear it
            if (messageInterval !== null) {
                clearInterval(messageInterval);
            }

            // Start a new interval to fetch messages every 2 seconds
            messageInterval = setInterval(function() {
                if (userId) {
                    fetchMessages(userId);  // Fetch messages for the selected user every 2 seconds
                }
            }, 2000);
        }

        $(document).ready(function() {
            fetchUsers();  // Load user list when page loads

            // When a user from the list is clicked, load their chat and start auto-fetching
            $(document).on('click', '.user-item', function() {
                currentUserId = $(this).data('id');  // Get the selected user's ID
                fetchMessages(currentUserId);  // Fetch messages for the selected user
                startAutoFetchMessages(currentUserId);  // Start auto-fetching messages every 2 seconds
            });

            // Send message
            $('#sendMessage').click(function() {
                var message = $('#message').val();
                if (message != '' && currentUserId !== null) {
                    $.ajax({
                        url: 'send_message.php',
                        method: 'POST',
                        data: {
                            sender: 'admin',
                            receiver: 'user',
                            message: message,
                            userId: currentUserId
                        },
                        success: function() {
                            $('#message').val('');  // Clear the message input field
                            fetchMessages(currentUserId);  // Refresh the chat after sending the message
                        }
                    });
                }
            });
        });
    </script>
</body>
</html>
