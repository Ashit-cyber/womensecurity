<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "womensecurity";
session_start();
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['sender']) && isset($_POST['receiver']) && isset($_POST['message'])) {
    $sender = $_POST['sender'];
    $receiver = $_POST['receiver'];
    $message = $_POST['message'];
    if ($_POST['sender'] === 'admin') {
        // If sender is admin, use the user ID from the POST request
        $userId = $_POST['userId'];
    } else {
        // If sender is not admin, use the user ID from the session
        $userId = $_SESSION['userId'];
    }

    $sql = "INSERT INTO messages (sender, receiver, message,user_id) VALUES ('$sender', '$receiver', '$message','$userId')";

    if ($conn->query($sql) === TRUE) {
        echo "Message sent successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
