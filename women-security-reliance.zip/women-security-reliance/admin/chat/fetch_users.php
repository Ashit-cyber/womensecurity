<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "womensecurity";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch users (excluding the admin)
$sql = "SELECT * FROM users";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo "<div class='user-item' data-id='" . $row['id'] . "'>" . $row['email'] . "</div>";
    }
} else {
    echo "No users found";
}

$conn->close();
?>
